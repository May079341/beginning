package kbz;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.net.MalformedURLException;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Kdemo_1 {

	WebDriver driver;

	@BeforeClass
	public void start() {
//		Map<String, Object> prefers = new HashMap<String, Object>();
//		prefers.put("profile.default_content_setting_values.notification",1);
//		ChromeOptions chromeOpt = new ChromeOptions();
//		chromeOpt.setExperimentalOption("prefs",prefers);

		
		  WebDriverManager.chromedriver().setup();
		  
		  ChromeOptions options = new ChromeOptions(); 
		  options.addArguments("use-fake-device-for-media-stream"); 
		  options.addArguments("use-fake-ui-for-media-stream"); 
		  options.addArguments("--allow-file-access-from-files",
		  "--use-fake-ui-for-media-stream", "--allow-file-access", "--use-file-for-fake-audio-capture=D:",  "--use-fake-device-for-media-stream");
		  
		  driver = new ChromeDriver(options);
		 
//		WebDriverManager.chromedriver().setup();
//		driver = new ChromeDriver(chromeOpt);

		driver.get("https://selfservice-uat.kbzbank.com");
		driver.manage().window().maximize();
		driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
		
	}

	@Test (enabled = true)
	public void SignIn() throws InterruptedException, AWTException  {
		
		Thread.sleep(3000);
		driver.findElement(By.xpath("//button[contains(text(),'Sign In')]")).click();
		Thread.sleep(4000);
		driver.getCurrentUrl();
		driver.findElement(By.xpath("//input[@id='formBasicEmail']")).sendKeys("maythandaroo720@gmail.com");
		driver.findElement(By.xpath("//input[@id='formBasicPassword']")).sendKeys("Bx0@jcbw");
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
		Thread.sleep(4000);
		}
	
	@Test (enabled = false)
	public void Dashboard() throws InterruptedException, AWTException  {
				
		driver.getCurrentUrl();
		JavascriptExecutor je = (JavascriptExecutor) driver;
	//	WebElement ele = driver.findElement(By.linkText("View all features"));
	//	je.executeScript("arguments[0].scrollIntoView();", ele);	// till the specific words found 

		driver.findElement(By.xpath("(//button[@class='btn-profile dropdown-toggle btn btn-primary'])[1]")).click();
		Thread.sleep(4000);
		je.executeScript("window.scrollTo(0, document.body.scrollHeight)","");
		Thread.sleep(3000);
		driver.navigate().back();
//		driver.findElement(By.xpath("(//a[@class='dropdown-item'])[2]")).click();
//		Thread.sleep(6000);
		}
	
	@Test (enabled = true)	// 1-Saving Individual
	private void Create_acc301() throws InterruptedException, AWTException, MalformedURLException {
		
		driver.getCurrentUrl();
		Thread.sleep(4000);
        JavascriptExecutor j = (JavascriptExecutor) driver;
        WebElement ele = driver.findElement(By.xpath("(//a[@class='btn btn-more-primary'])[1]"));	//learn more btn
        j.executeScript("arguments[0].click();", ele);
        Thread.sleep(8000);
       
        JavascriptExecutor j1 = (JavascriptExecutor) driver;
        WebElement ele1 = driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]"));	//create acc btn
        j1.executeScript("arguments[0].click();", ele1);
        Thread.sleep(8000);       
        
        JavascriptExecutor j2 = (JavascriptExecutor) driver;
        WebElement ele2 = driver.findElement(By.xpath("//input[@id='inline-radio-2']"));	//gallery radio btn
        j2.executeScript("arguments[0].click();", ele2);
        Thread.sleep(3000);
        j2.executeScript("arguments[0].click();", ele2);
		Thread.sleep(6000);
        		
		Actions action = new Actions(driver);
		
        WebElement ele3 = driver.findElement(By.xpath("(//div[@class='col-md-1'])[1]"));  //nrc front upload btn
        action.moveToElement(ele3).click().build().perform();
		Thread.sleep(6000);
		
		Robot k = new Robot();
		
		String path = "D:\\Automation tasks";
		StringSelection pathss = new StringSelection(path);	// path select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pathss, null); // copied 
		
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(5000);
				
		String st = "WallpaperBG-1.jpg";
		StringSelection ss = new StringSelection(st);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);	// copied

		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);

		WebElement ele4 = driver.findElement(By.xpath("//div[@class='col-md-1']"));  //nrc back upload btn
        action.moveToElement(ele4).click().build().perform();
		Thread.sleep(6000);
				
		// no need to go to file path 
		String st1 = "WallpaperBG-2.jpg";
		StringSelection ss1 = new StringSelection(st1);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss1, null);	
				
//		action.keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).build().perform();
//		action.keyDown(Keys.ENTER).keyUp(Keys.ENTER).build().perform();
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);
		
		JavascriptExecutor j3 = (JavascriptExecutor) driver;
		j3.executeScript("window.scrollBy(0,document.body.scrollHeight);", "");
		WebElement ele5 = driver.findElement(By.xpath("//button[@class='ca-continue-btn btn btn-primary']"));  // continue btn		
		action.moveToElement(ele5).click().build().perform();
		Thread.sleep(5000);
			
		}
/*	
	@Test (enabled = false)	// 2-Cash Account - Savings Individual
	public void Create_acc325() throws InterruptedException, AWTException  {
		
		driver.getCurrentUrl();
		Thread.sleep(4000);
        JavascriptExecutor j = (JavascriptExecutor) driver;
        WebElement ele = driver.findElement(By.xpath("(//a[@class='btn btn-more-primary'])[2]"));	//learn more btn
        j.executeScript("arguments[0].click();", ele);
        Thread.sleep(8000);
                   
        JavascriptExecutor j1 = (JavascriptExecutor) driver;
        WebElement ele1 = driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]"));	//create acc btn
        j1.executeScript("arguments[0].click();", ele1);
        Thread.sleep(8000);       
        
        JavascriptExecutor j2 = (JavascriptExecutor) driver;
        WebElement ele2 = driver.findElement(By.xpath("//input[@id='inline-radio-2']"));	//gallery radio btn
        j2.executeScript("arguments[0].click();", ele2);
        Thread.sleep(3000);
        j2.executeScript("arguments[0].click();", ele2);
		Thread.sleep(6000);
        		
		Actions action = new Actions(driver);
		
        WebElement ele3 = driver.findElement(By.xpath("(//div[@class='col-md-1'])[1]"));  //nrc front upload btn
        action.moveToElement(ele3).click().build().perform();
		Thread.sleep(6000);
		
		Robot k = new Robot();
		
		String path = "D:\\Automation tasks";
		StringSelection pathss = new StringSelection(path);	// path select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pathss, null); // copied 
		
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(5000);
				
		String st = "WallpaperBG-1.jpg";
		StringSelection ss = new StringSelection(st);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);	// copied

		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);

		WebElement ele4 = driver.findElement(By.xpath("//div[@class='col-md-1']"));  //nrc back upload btn
        action.moveToElement(ele4).click().build().perform();
		Thread.sleep(6000);
				
		// no need to go to file path 
		String st1 = "WallpaperBG-2.jpg";
		StringSelection ss1 = new StringSelection(st1);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss1, null);	
				
//		action.keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).build().perform();
//		action.keyDown(Keys.ENTER).keyUp(Keys.ENTER).build().perform();
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);
		
		JavascriptExecutor j3 = (JavascriptExecutor) driver;
		j3.executeScript("window.scrollBy(0,document.body.scrollHeight);", "");
		WebElement ele5 = driver.findElement(By.xpath("//button[@class='ca-continue-btn btn btn-primary']"));  // continue btn		
		action.moveToElement(ele5).click().build().perform();
		Thread.sleep(5000);
			
		}

	@Test (enabled = false)	// 3-Current Account - Individual
	public void Create_acc101() throws InterruptedException, AWTException  {
		
		driver.getCurrentUrl();
		Thread.sleep(4000);
        JavascriptExecutor j = (JavascriptExecutor) driver;
        WebElement ele = driver.findElement(By.xpath("(//a[@class='btn btn-more-primary'])[3]"));	//learn more btn
        j.executeScript("arguments[0].click();", ele);
        Thread.sleep(8000);
        
        JavascriptExecutor j1 = (JavascriptExecutor) driver;
        WebElement ele1 = driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]"));	//create acc btn
        j1.executeScript("arguments[0].click();", ele1);
        Thread.sleep(8000);       
        
        JavascriptExecutor j2 = (JavascriptExecutor) driver;
        WebElement ele2 = driver.findElement(By.xpath("//input[@id='inline-radio-2']"));	//gallery radio btn
        j2.executeScript("arguments[0].click();", ele2);
        Thread.sleep(3000);
        j2.executeScript("arguments[0].click();", ele2);
		Thread.sleep(6000);
        		
		Actions action = new Actions(driver);
		
        WebElement ele3 = driver.findElement(By.xpath("(//div[@class='col-md-1'])[1]"));  //nrc front upload btn
        action.moveToElement(ele3).click().build().perform();
		Thread.sleep(6000);
		
		Robot k = new Robot();
		
		String path = "D:\\Automation tasks";
		StringSelection pathss = new StringSelection(path);	// path select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pathss, null); // copied 
		
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(5000);
				
		String st = "WallpaperBG-1.jpg";
		StringSelection ss = new StringSelection(st);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);	// copied

		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);

		WebElement ele4 = driver.findElement(By.xpath("//div[@class='col-md-1']"));  //nrc back upload btn
        action.moveToElement(ele4).click().build().perform();
		Thread.sleep(6000);
				
		// no need to go to file path 
		String st1 = "WallpaperBG-2.jpg";
		StringSelection ss1 = new StringSelection(st1);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss1, null);	
				
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);
		
		JavascriptExecutor j3 = (JavascriptExecutor) driver;
		j3.executeScript("window.scrollBy(0,document.body.scrollHeight);", "");
		WebElement ele5 = driver.findElement(By.xpath("//button[@class='ca-continue-btn btn btn-primary']"));  // continue btn		
		action.moveToElement(ele5).click().build().perform();
		Thread.sleep(5000);
				
		}
	
	@Test (enabled = false)	// 4-Current Account - Individual Resident
	public void Create_acc107() throws InterruptedException, AWTException  {
		
		driver.getCurrentUrl();
		Thread.sleep(4000);
        JavascriptExecutor j = (JavascriptExecutor) driver;
        WebElement ele = driver.findElement(By.xpath("(//a[@class='btn btn-more-primary'])[4]"));	//learn more btn
        j.executeScript("arguments[0].click();", ele);
        Thread.sleep(8000);
        
        JavascriptExecutor j1 = (JavascriptExecutor) driver;
        WebElement ele1 = driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]"));	//create acc btn
        j1.executeScript("arguments[0].click();", ele1);
        Thread.sleep(8000);       
        
        JavascriptExecutor j2 = (JavascriptExecutor) driver;
        WebElement ele2 = driver.findElement(By.xpath("//input[@id='inline-radio-2']"));	//gallery radio btn
        j2.executeScript("arguments[0].click();", ele2);
        Thread.sleep(3000);
        j2.executeScript("arguments[0].click();", ele2);
		Thread.sleep(6000);
        		
		Actions action = new Actions(driver);
		
        WebElement ele3 = driver.findElement(By.xpath("(//div[@class='col-md-1'])[1]"));  //nrc front upload btn
        action.moveToElement(ele3).click().build().perform();
		Thread.sleep(6000);
		
		Robot k = new Robot();
		
		String path = "D:\\Automation tasks";
		StringSelection pathss = new StringSelection(path);	// path select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pathss, null); // copied 
		
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(5000);
				
		String st = "WallpaperBG-1.jpg";
		StringSelection ss = new StringSelection(st);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);	// copied

		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);

		WebElement ele4 = driver.findElement(By.xpath("//div[@class='col-md-1']"));  //nrc back upload btn
        action.moveToElement(ele4).click().build().perform();
		Thread.sleep(6000);
				
		// no need to go to file path 
		String st1 = "WallpaperBG-2.jpg";
		StringSelection ss1 = new StringSelection(st1);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss1, null);	
				
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);
		
		JavascriptExecutor j3 = (JavascriptExecutor) driver;
		j3.executeScript("window.scrollBy(0,document.body.scrollHeight);", "");
		WebElement ele5 = driver.findElement(By.xpath("//button[@class='ca-continue-btn btn btn-primary']"));  // continue btn		
		action.moveToElement(ele5).click().build().perform();
		Thread.sleep(5000);
		
		}
	
	@Test (enabled = false)	// 5-Current Account - Individual Non-Resident // can't test for now
	public void Create_acc108() throws InterruptedException, AWTException  {
		
		driver.getCurrentUrl();
		Thread.sleep(4000);
        JavascriptExecutor j = (JavascriptExecutor) driver;
        WebElement ele = driver.findElement(By.xpath("(//a[@class='btn btn-more-primary'])[5]"));	//learn more btn
        j.executeScript("arguments[0].click();", ele);
        Thread.sleep(8000);
        
        JavascriptExecutor j1 = (JavascriptExecutor) driver;
        WebElement ele1 = driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]"));	//create acc btn
        j1.executeScript("arguments[0].click();", ele1);
        Thread.sleep(8000);       
        
        JavascriptExecutor j2 = (JavascriptExecutor) driver;
        WebElement ele2 = driver.findElement(By.xpath("//input[@id='inline-radio-2']"));	//gallery radio btn
        j2.executeScript("arguments[0].click();", ele2);
        Thread.sleep(3000);
        j2.executeScript("arguments[0].click();", ele2);
		Thread.sleep(6000);
        		
		Actions action = new Actions(driver);
		
        WebElement ele3 = driver.findElement(By.xpath("(//div[@class='col-md-1'])[1]"));  //nrc front upload btn
        action.moveToElement(ele3).click().build().perform();
		Thread.sleep(6000);
		
		Robot k = new Robot();
		
		String path = "D:\\Automation tasks";
		StringSelection pathss = new StringSelection(path);	// path select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pathss, null); // copied 
		
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(5000);
				
		String st = "WallpaperBG-1.jpg";
		StringSelection ss = new StringSelection(st);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);	// copied

		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);

		WebElement ele4 = driver.findElement(By.xpath("//div[@class='col-md-1']"));  //nrc back upload btn
        action.moveToElement(ele4).click().build().perform();
		Thread.sleep(6000);
				
		// no need to go to file path 
		String st1 = "WallpaperBG-2.jpg";
		StringSelection ss1 = new StringSelection(st1);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss1, null);	
				
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);
		
		JavascriptExecutor j3 = (JavascriptExecutor) driver;
		j3.executeScript("window.scrollBy(0,document.body.scrollHeight);", "");
		WebElement ele5 = driver.findElement(By.xpath("//button[@class='ca-continue-btn btn btn-primary']"));  // continue btn		
		action.moveToElement(ele5).click().build().perform();
		Thread.sleep(5000);
		
		}
	
	@Test (enabled = false)	// 6-Cash Account - Current Individual
	public void Create_acc137() throws InterruptedException, AWTException  {
		
		driver.getCurrentUrl();
		Thread.sleep(4000);
        JavascriptExecutor j = (JavascriptExecutor) driver;
        WebElement ele = driver.findElement(By.xpath("(//a[@class='btn btn-more-primary'])[6]"));	//learn more btn
        j.executeScript("arguments[0].click();", ele);
        Thread.sleep(8000);
        
        JavascriptExecutor j1 = (JavascriptExecutor) driver;
        WebElement ele1 = driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]"));	//create acc btn
        j1.executeScript("arguments[0].click();", ele1);
        Thread.sleep(8000);       
        
        JavascriptExecutor j2 = (JavascriptExecutor) driver;
        WebElement ele2 = driver.findElement(By.xpath("//input[@id='inline-radio-2']"));	//gallery radio btn
        j2.executeScript("arguments[0].click();", ele2);
        Thread.sleep(3000);
        j2.executeScript("arguments[0].click();", ele2);
		Thread.sleep(6000);
        		
		Actions action = new Actions(driver);
		
        WebElement ele3 = driver.findElement(By.xpath("(//div[@class='col-md-1'])[1]"));  //nrc front upload btn
        action.moveToElement(ele3).click().build().perform();
		Thread.sleep(6000);
		
		Robot k = new Robot();
		
		String path = "D:\\Automation tasks";
		StringSelection pathss = new StringSelection(path);	// path select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pathss, null); // copied 
		
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(5000);
				
		String st = "WallpaperBG-1.jpg";
		StringSelection ss = new StringSelection(st);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);	// copied

		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);

		WebElement ele4 = driver.findElement(By.xpath("//div[@class='col-md-1']"));  //nrc back upload btn
        action.moveToElement(ele4).click().build().perform();
		Thread.sleep(6000);
				
		// no need to go to file path 
		String st1 = "WallpaperBG-2.jpg";
		StringSelection ss1 = new StringSelection(st1);	//image file select 
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss1, null);	
				
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);
		
		JavascriptExecutor j3 = (JavascriptExecutor) driver;
		j3.executeScript("window.scrollBy(0,document.body.scrollHeight);", "");
		WebElement ele5 = driver.findElement(By.xpath("//button[@class='ca-continue-btn btn btn-primary']"));  // continue btn		
		action.moveToElement(ele5).click().build().perform();
		Thread.sleep(5000);
		}
*/	
	@AfterClass
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(2000);		
		driver.quit();
		System.out.println("The driver closed the browser entirely.");
		
	}
}	