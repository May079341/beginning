package kbz;

import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.concurrent.TimeUnit;
import java.awt.AWTException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class demo1 {

	WebDriver driver;

	@BeforeClass
	public void start() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.manage().window().maximize();
	}

	@Test (enabled = true)
	public void test_scrollPage() throws InterruptedException, AWTException  {
		
		driver.get("https://www.browserstack.com/automate");
		JavascriptExecutor je = (JavascriptExecutor) driver;
		Robot k = new Robot();
		
		je.executeScript("window.scrollTo(0,document.body.scrollHeight)", "");	// till the end of page
		je.executeScript("window.scrollBy(0,-600)", "");	// specified pixels (go up)
		je.executeScript("window.scrollBy(0,350)", "");		// specified pixels (go down)
		
		WebElement ele = driver.findElement(By.linkText("View all features"));
		je.executeScript("arguments[0].scrollIntoView();", ele);	// till the specific words found 

		k.keyPress(KeyEvent.VK_PAGE_DOWN);
		k.keyPress(KeyEvent.VK_PAGE_UP);
		Thread.sleep(2000);

		}
		
	@Test (enabled = true)
	public void test_assertion() throws InterruptedException, AWTException  {
				
		driver.get("https://www.browserstack.com/");
		String actual_title = driver.getTitle();
		String exp_title = "Most Reliable App & Cross Browser Testing Platform | BrowserStack";
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(actual_title, exp_title);
		System.out.println(actual_title);
		Thread.sleep(1000);
		
		driver.navigate().to("https://www.browserstack.com/automate");	
		String actualT = driver.getTitle();
		String expT = "Automated Selenium Testing On A Grid of 3000+ Browsers & Mobile Devices | BrowserStack";
		Assert.assertEquals(expT, actualT);
		System.out.println(actualT);				
		Thread.sleep(1000);
		}
	
	@AfterClass
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(2000);		
		driver.quit();
		System.out.println("The driver closed the browser entirely.");
	}	