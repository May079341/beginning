package kbz;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class demo {

	WebDriver driver;

	@BeforeClass
	public void start() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		/*
		driver.get("https://leetcode.com/accounts/login/?next=");
		  
		String verifyURL = driver.getCurrentUrl(); 
		if (verifyURL.equals("https://leetcode.com/accounts/login/?next=")) 
		{
		  System.out.println(driver.getCurrentUrl());		  
		} 
		else { System.out.println("URL Verification Fail"); }
		*/ 

		System.out.println(driver.getTitle());

		 driver.manage().window().maximize();
	}
	
	@Test(enabled = false)
	public void sign_in() throws InterruptedException, AWTException {

		driver.get("https://www.browserstack.com/automate");
		
		Robot k = new Robot();
//		driver.findElement(By.xpath("//input[@id='id_login']")).sendKeys("mto@gmail.com");
//		k.keyPress(KeyEvent.VK_TAB);
//		k.keyRelease(KeyEvent.VK_TAB);
		
//		driver.findElement(By.xpath("(//div[@class='heading ' and @text='Enterprise-class features'])[2]")).isSelected();		

		String st = "Enterprise-class features";
		StringSelection ss = new StringSelection(st);	//select all
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null);	//copy text in clipboard
		
		driver.findElement(By.xpath("//button[@class='doc-search-mobile-cta doc-search-menu-icon doc-menu-toggle']")).click();
		driver.findElement(By.xpath("//input[@id='doc-search-box-input']")).sendKeys("search works");
		k.keyPress(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_CONTROL);
		
//		driver.findElement(By.xpath("//input[@id='id_password']")).sendKeys("!@#123mto");
//		k.keyPress(KeyEvent.VK_TAB);
//		k.keyRelease(KeyEvent.VK_TAB);
//		driver.findElement(By.id("signin_btn")).click();
//		driver.findElement(By.xpath("//span[@data-cy='sign-up-link']")).click();
//		driver.findElement(By.xpath("//a[@href=\"/accounts/password/reset/\"]")).click();
		Thread.sleep(2000);
//		System.out.println("Sign In SUCCESS");
	}
	
	@Test(enabled = false)
	public void sign_up() throws InterruptedException {
		
		driver.findElement(By.xpath("//input[@placeholder='Username']")).sendKeys("Thandar");
		driver.findElement(By.xpath("//input[@placeholder='Password']")).sendKeys("!@#123mto");
		driver.findElement(By.xpath("//input[@placeholder='Confirm password']")).sendKeys("!@#123mto");
		driver.findElement(By.xpath("//input[@placeholder='E-mail address']")).sendKeys("mto@gmail.com");
		driver.findElement(By.xpath("//button[@data-cy='sign-up-btn']")).click();
		Thread.sleep(2000);
		System.out.println("Signed Up successfully.");
	}

	@Test(enabled = false) 
	public void forget_pswd() throws InterruptedException {
	  
		driver.getCurrentUrl();
		driver.findElement(By.xpath("//input[@id='id_email']")).sendKeys("mto@gmail.com");
		driver.findElement(By.xpath("//button[@name='password_reset_btn']")).click();
		Thread.sleep(2000);
//		driver.quit(); 
	}

	@AfterClass
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(3000);
		driver.close();
		driver.quit();
		System.out.println("The driver closed the browser entirely.");
	}

}
