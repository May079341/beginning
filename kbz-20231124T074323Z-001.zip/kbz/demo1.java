package kbz;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.asserts.SoftAssert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class demo1 {

	WebDriver driver;

	@BeforeClass
	public void start() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
/*		
		driver.get("http://automationpractice.com/index.php");

		String verifyURL = driver.getCurrentUrl();
		if (verifyURL.equals("http://automationpractice.com/index.php")) {
			System.out.println(driver.getCurrentUrl());

		} else {
			System.out.println("URL Verification Fail");
		}
*/
//		System.out.println(driver.getTitle());

		driver.manage().window().maximize();
	}
	
	@Test (enabled = false)
	public void search() throws InterruptedException  {
	
//		driver.findElement(By.xpath("//input[@id='search_query_top']")).sendKeys("blazer");
//		driver.findElement(By.xpath("//button[@name='submit_search']")).click();
		driver.findElement(By.xpath("//a[@href='http://automationpractice.com/index.php?controller=order']")).click();	//view cart
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		Thread.sleep(2000);
	}
	
	@Test (enabled = false)
	public void subMenu() throws InterruptedException  {
	
//		driver.findElement(By.xpath("//a[@title='Women']")).click();
//		driver.findElement(By.xpath("//a[@title='Dresses']")).click();
		driver.findElement(By.xpath("//a[@href='http://automationpractice.com/index.php?id_category=5&controller=category']")).click();
		Thread.sleep(2000);
	}
	
	@Test (enabled = false)
	public void choice() throws InterruptedException, AWTException  {
	
//		Actions act = new Actions(driver);
		Robot r = new Robot();
		
		r.keyPress(KeyEvent.VK_PAGE_DOWN);
		r.keyPress(KeyEvent.VK_PAGE_UP);
		
		driver.findElement(By.xpath("//input[@id='newsletter-input']")).sendKeys("mto@g.com");
		driver.findElement(By.xpath("//button[@name='submitNewsletter']")).click();
		driver.quit();
	}
	
	@Test (enabled = false)
	public void scrollPage() throws InterruptedException, AWTException  {
		
		driver.get("https://www.browserstack.com/automate");
		JavascriptExecutor je = (JavascriptExecutor) driver;
//		Actions act = new Actions(driver);
		
		je.executeScript("window.scrollBy(0,document.body.scrollHeight)", "");	// till the end of page
		je.executeScript("window.scrollBy(0,-800)", "");	// specified pixels (go up)
//		je.executeScript("window.scrollBy(0,450)", "");	  // specified pixels (go down)
		Thread.sleep(2000);
		WebElement ele = driver.findElement(By.linkText("View all features"));
		je.executeScript("arguments[0].scrollIntoView();", ele);	// till the words found (both vertical & horizontal)
//		act.moveToElement(ele).build().perform();
//		ele.click();
		Thread.sleep(2000);
		}
	
	@Test (enabled = false)
	public void selection() throws InterruptedException, AWTException  {
		
		driver.get("https://www.browserstack.com/automate/features");

		JavascriptExecutor jj = (JavascriptExecutor) driver;

		WebElement ee = driver.findElement(By.partialLinkText("Integrate effortlessly"));
		jj.executeScript("arguments[0].scrollIntoView();", ee);
		Thread.sleep(1000);		
		
		driver.findElement(By.xpath("button[@id='java-tab']"));
		driver.findElement(By.xpath("button[@id='node-tab']"));
		driver.findElement(By.xpath("button[@id='python-tab']"));
		driver.findElement(By.xpath("button[@id='csharp-tab']"));
		driver.findElement(By.xpath("button[@id='php-tab']"));
		Thread.sleep(2000);
		}
	
	@Test (enabled = false)
	public void test_assertion() throws InterruptedException, AWTException  {
				
		driver.get("https://www.browserstack.com/");
		String actual_title = driver.getTitle();
		String exp_title = "Most Reliable App & Cross Browser Testing Platform | BrowserStack";
		SoftAssert sa = new SoftAssert();
		sa.assertEquals(actual_title, exp_title);
		System.out.println(actual_title);
		Thread.sleep(2000);
		
		driver.navigate().to("https://www.browserstack.com/automate");	
		String actualT = driver.getTitle();
		String expT = "Automated Selenium Testing On A Grid of 3000+ Browsers & Mobile Devices | BrowserStack";
		Assert.assertEquals(expT, actualT);
		System.out.println(actualT);				
		Thread.sleep(2000);
		
		//for FCY
        JavascriptExecutor je1 = (JavascriptExecutor) driver;
        WebElement element1 = driver.findElement(By.xpath("(//div[@class=' css-tlfecz-indicatorContainer'])[1]"));	//select currency btn
        je1.executeScript("arguments[0].click();", element1);
        Thread.sleep(3000);
//        JavascriptExecutor je2 = (JavascriptExecutor) driver;
//        WebElement elem1 = driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]"));	//currency btn
//        je2.executeScript("arguments[0].click();", elem1);
//        Thread.sleep(5000);
		}
	
	@Test (enabled = true)
	public void windowHandle() throws InterruptedException, AWTException  {
				
		driver.get("https://letcode.in/windows");
		
		Set<String> wd = driver.getWindowHandles();
		System.out.println(wd);
		List<String> li = new ArrayList<String>(wd);		

		driver.findElement(By.xpath("//button[@id='home']")).click();		
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		driver.switchTo().window(li.get(0));		
		System.out.println(li.size());
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//button[@id='multi']")).click();		
		Thread.sleep(3000);
		Set<String> wd1 = driver.getWindowHandles();
//		System.out.println(wd1);
		li.clear();
		li.addAll(wd1);
		System.out.println(li);
/*
		driver.switchTo().window(li.get(0));
		Thread.sleep(4000);
		driver.findElement(By.xpath("//a[@href='/test']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[@href='/courses']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath("//a[@href='/letxpath']")).click();
		Thread.sleep(5000);
*/		
		driver.switchTo().window(li.get(3)); // alert pg
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		driver.close();
		driver.switchTo().window(li.get(2)); // dropdown pg
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		driver.close();
		driver.switchTo().window(li.get(1)); //test pg
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		driver.close();
		driver.switchTo().window(li.get(0)); // home pg
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		driver.close();
		
		System.out.println(li.size());
		Thread.sleep(4000);

	}
	
	@AfterClass
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(2000);		
		driver.quit();
		System.out.println("The driver closed the browser entirely.");
	}
}
