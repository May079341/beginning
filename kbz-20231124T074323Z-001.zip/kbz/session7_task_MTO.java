package kbz;

import java.awt.AWTException;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class demo1 {

	WebDriver driver;

	@BeforeClass
	public void startBrowser() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		
		driver.get("https://letcode.in/windows");

		System.out.println(driver.getTitle());

		driver.manage().window().maximize();
	}

	@Test (enabled = true)
	public void windowHandle() throws InterruptedException, AWTException  {
		
		Set<String> wd = driver.getWindowHandles();
		System.out.println(wd);
		List<String> li = new ArrayList<String>(wd);		

		driver.findElement(By.xpath("//button[@id='home']")).click();		
		Thread.sleep(4000);
		System.out.println(driver.getCurrentUrl());
		driver.switchTo().window(li.get(0));		
		System.out.println(li.size());
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//button[@id='multi']")).click();
		Thread.sleep(4000);
		Set<String> wd1 = driver.getWindowHandles();
		li.clear();
		li.addAll(wd1);
		System.out.println(li);
		
		driver.switchTo().window(li.get(3)); //dropdown pg
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		driver.close();
		driver.switchTo().window(li.get(2)); // alert pg
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		driver.close();
		driver.switchTo().window(li.get(1)); //test pg
		Thread.sleep(3000);
		System.out.println(driver.getCurrentUrl());
		driver.close();
		
		System.out.println(li.size());
		Thread.sleep(4000);
	}

}	