package kbz;

import java.awt.AWTException;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Kdemo_4 {
	
    WebDriver driver;

    @BeforeClass
    public void startBrowser() {
    	WebDriverManager.chromedriver().setup();
    	
        driver = new ChromeDriver();        
        
        driver.get("http://adminportal144-uat.kbzbank.com.s3-website-ap-southeast-1.amazonaws.com/");

        driver.manage().window().maximize();

    }

    @Test(enabled = false)
    public void signIn() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);                
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys("024897");  // 009685
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Mto@14397");  // Dd21031991%%%
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(4000);        
    }
    
    @Test(enabled = false)	// Hub
    public void hub() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);                
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys("024897");  // 009685
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Mto@14397");  // Dd21031991%%%
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(7000);       
        
    	JavascriptExecutor j0= (JavascriptExecutor) driver;    	
    	WebElement e0 = driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[1]"));	// go to Hub
    	j0.executeScript("arguments[0].click();", e0);
    	Thread.sleep(6000);
    	
    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// refresh btn
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//input[@placeholder='From Date']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@placeholder='To Date']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@placeholder='Enter  NRC or CIF']")).click();
    	Thread.sleep(2000);
    	
    	driver.findElement(By.xpath("(//button[@class='btn btn-sm btn-danger'])[3]")).click(); // pick up (3)
    	Thread.sleep(3000);
    	driver.switchTo().alert().accept();
//    	driver.switchTo().alert().dismiss();
    	Thread.sleep(4000);
    }
    
    @Test(enabled = false)	// My Inbox of maker
    public void myInbox() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);                
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys("024897");  // 009685
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Mto@14397");  // Dd21031991%%%
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(7000);       
            	
//    	driver.findElement(By.xpath("//input[@placeholder='From Date']")).sendKeys("2022-09-28");
//    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//input[@placeholder='To Date']")).sendKeys("2022-10-17");
//    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//input[@placeholder='Enter  NRC or CIF']")).click();    	
//    	Thread.sleep(3000);        
    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// refresh btn
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//label[@class='btn btn-outline-primary'])[1]")).click();	// submit tab
    	Thread.sleep(3000);        
    	
//    	driver.findElement(By.xpath("(//label[@class='btn btn-outline-primary'])[2]")).click();	// approve tab
//    	Thread.sleep(3000);
//    	driver.findElement(By.xpath("(//label[@class='btn btn-outline-primary'])[3]")).click();	// reject tab
//    	Thread.sleep(3000);
//    	driver.findElement(By.xpath("(//label[@class='btn btn-outline-primary'])[4]")).click();	// complete tab
//    	Thread.sleep(4000);  
    	
    	driver.findElement(By.xpath("(//a[text()='Edit'])[1]")).click(); // 1st row
    	Thread.sleep(4000);
    	    	
    	driver.findElement(By.xpath("(//a[@class='nav-link'])[2]")).click(); // Introducer/Validator 1
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("(//a[@class='nav-link'])[3]")).click(); // Introducer/Validator 2
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("(//a[@class='nav-link'])[4]")).click(); // Pre-Approve/Pre-Reject
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//textarea[@id='exampleForm.ControlTextarea1']")).sendKeys("pass to checker to be approved"); // input Remark
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//button[@class='approvebutton btn btn-primary']")).click(); // Pre-approve btn
    	Thread.sleep(2000);
    	driver.switchTo().alert().accept();
//    	driver.findElement(By.xpath("//button[@class='approvebutton btn btn-danger']")).click(); // Pre-reject btn
//    	Thread.sleep(2000);    	
//    	driver.switchTo().alert().accept();    	
    	
    	driver.findElement(By.xpath("//select[@class='form-control']")).click();
    	Thread.sleep(4000);
    	driver.findElement(By.xpath("//option[text()='Ingyin Khat ']")).click(); 
    	Thread.sleep(4000);
    	driver.findElement(By.xpath("//button[@class='approvebutton btn btn-primary']")).click();
    	Thread.sleep(4000);
    	driver.switchTo().alert().accept();
    	Thread.sleep(4000);  
    	driver.navigate().back();
    }
    	
// ------- Maker side finished -------   	
    	
//	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[1]")).click();	// go to My Inbox    	
//	Thread.sleep(4000);
//	driver.findElement(By.xpath("//label[@class='btn btn-outline-primary active']")).click();  // inbox tab
//	Thread.sleep(3000);  	
    	
    @Test(enabled = false)	// My Inbox of maker
    public void myInbox1() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);                
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys("024897");  // 009685
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Mto@14397");  // Dd21031991%%%
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(7000);       
            	
//    	driver.findElement(By.xpath("//input[@placeholder='From Date']")).sendKeys("2022-09-28");
//    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//input[@placeholder='To Date']")).sendKeys("2022-10-17");
//    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//input[@placeholder='Enter  NRC or CIF']")).click();    	
//    	Thread.sleep(3000);        
//    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// refresh btn
//    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//label[@class='btn btn-outline-primary'])[1]")).click();	// submit tab
    	Thread.sleep(3000);        
    	driver.findElement(By.xpath("(//a[text()='Edit'])[1]")).click(); // 1st row
    	Thread.sleep(4000);
    	    	
    	driver.findElement(By.xpath("(//a[@class='nav-link'])[2]")).click(); // Introducer/Validator 1
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("(//a[@class='nav-link'])[3]")).click(); // Introducer/Validator 2
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("(//a[@class='nav-link'])[4]")).click(); // Pre-Approve/Pre-Reject
    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//textarea[@id='exampleForm.ControlTextarea1']")).sendKeys("pass to checker to be approved"); // input Remark
//    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//button[@class='approvebutton btn btn-primary']")).click(); // Pre-approve btn
//    	Thread.sleep(2000);
//    	driver.switchTo().alert().accept();
//    	driver.findElement(By.xpath("//button[@class='approvebutton btn btn-danger']")).click(); // Pre-reject btn
//    	Thread.sleep(2000);    	
//    	driver.switchTo().alert().accept();    	
//    	driver.findElement(By.xpath("//select[@class='form-control']")).click();
//    	Thread.sleep(4000);
//    	driver.findElement(By.xpath("//option[text()='Ingyin Khat ']")).click(); // 1st row
//    	Thread.sleep(4000);
//    	driver.findElement(By.xpath("//button[@class='approvebutton btn btn-primary']")).click();
//    	Thread.sleep(4000);
//    	driver.switchTo().alert().accept();
    	Thread.sleep(4000);  
    	driver.navigate().back();
    }
    @AfterClass
   	public void closeBrowser() throws InterruptedException {
   		Thread.sleep(10000);		
   		driver.quit();
   		System.out.println("The driver closed the browser entirely.");
   	}	
}
