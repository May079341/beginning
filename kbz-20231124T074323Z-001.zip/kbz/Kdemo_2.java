package kbz;

import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.awt.AWTException;
import java.net.MalformedURLException;
import java.util.Map;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Kdemo_2 {
	
    WebDriver driver;

    @BeforeClass
    public void startBrowser() {
    	WebDriverManager.chromedriver().setup();
    	
        driver = new ChromeDriver();        
        
        driver.get("http://adminportal144-uat.kbzbank.com.s3-website-ap-southeast-1.amazonaws.com/");

        driver.manage().window().maximize();

    }

    @Test(enabled = true)
    public void signIn() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);                
        driver.findElement(By.xpath("//input[@name='username']")).sendKeys("024897");
        driver.findElement(By.xpath("//input[@name='password']")).sendKeys("Mto@14397");
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@type='submit']")).click();
        Thread.sleep(4000);
        System.out.println(driver.getCurrentUrl());
    }
/*   
    @Test(enabled = false)
    public void menu() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[1]")).click();	// go to Hub
    	Thread.sleep(7000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[1]")).click();	// go to My Inbox
    	Thread.sleep(7000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[2]")).click();	// go to Quick search
    	Thread.sleep(7000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[3]")).click();	// go to Daily rep
    	Thread.sleep(7000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[4]")).click();	// go to App/Rej rep
    	Thread.sleep(7000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[5]")).click();	// go to User Prog rep
    	Thread.sleep(7000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[6]")).click();	// Logout
    	Thread.sleep(4000);
    	driver.switchTo().alert().accept();
    	Thread.sleep(3000);  	
    }
*/       
    @Test(enabled = true)	// Hub
    public void menu1() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);
    	JavascriptExecutor j0= (JavascriptExecutor) driver;    	
    	WebElement e0 = driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[1]"));	// go to Hub
    	j0.executeScript("arguments[0].click();", e0);
    	Thread.sleep(6000);
    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// refresh btn
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//input[@placeholder='From Date']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@placeholder='To Date']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@placeholder='Enter  NRC or CIF']")).click();
    	Thread.sleep(2000);
    	
    	driver.findElement(By.xpath("(//button[@class='btn btn-sm btn-danger'])[3]")).click(); // pick up 3rd
    	Thread.sleep(3000);
    	driver.switchTo().alert().accept();
//    	driver.switchTo().alert().dismiss();
    	Thread.sleep(4000);
    }
    
    @Test(enabled = false)	// My Inbox
    public void menu2() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[1]")).click();	// go to My Inbox    	
    	Thread.sleep(4000);
    	driver.findElement(By.xpath("//label[@class='btn btn-outline-primary active']")).click();	// inbox tab
    	Thread.sleep(3000);
//    	driver.findElement(By.xpath("//label[@for='btnradio2']")).click();	// submit tab
//    	Thread.sleep(3000);
//    	driver.findElement(By.xpath("(//label[@for='btnradio3'])[1]")).click();	// approve tab
//    	Thread.sleep(3000);
//    	driver.findElement(By.xpath("(//label[@for='btnradio3'])[2]")).click();	// reject tab
//    	Thread.sleep(3000);
//    	driver.findElement(By.xpath("(//label[@for='btnradio3'])[3]")).click();	// complete tab
//    	Thread.sleep(4000);

    	driver.findElement(By.xpath("//input[@placeholder='From Date']")).sendKeys("2022-09-28");
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@placeholder='To Date']")).sendKeys("2022-10-14");
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@placeholder='Enter  NRC or CIF']")).click();    	
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// refresh btn
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("//a[text()='Edit']")).click();
    	Thread.sleep(4000);
    	
    }
/*    
    @Test(enabled = true)	// Quick Search
    public void menu3() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[2]")).click();	// go to Quick Search
    	Thread.sleep(6000);    	
    	
    	driver.findElement(By.xpath("//input[@placeholder='From Date']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//div[contains(@class,'react-datepicker__day react-datepicker__day--022')]")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@placeholder='To Date']")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//div[contains(@class,'react-datepicker__day react-datepicker__day--027')]")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@placeholder='Enter NRC or CIF ']")).sendKeys("1/AHGAYA(N)976654");    	
    	Thread.sleep(3000);
    	
    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// refresh btn
    	Thread.sleep(3000);
    }
    
    @Test(enabled = true)	// Daily Report
    public void menu4() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[3]")).click();	// go to Daily Report
    	Thread.sleep(6000);    	
    	driver.findElement(By.xpath("//input[@placeholder='Enter DocumentNo or CIF ']")).click();    	
    	Thread.sleep(3000);
    	
    	driver.findElement(By.xpath("(//span[@class=' css-1okebmr-indicatorSeparator']/following-sibling::div)[1]")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//input[@id='react-select-2-input']")).sendKeys("maker"); // hub, checker   	
    	Robot k = new Robot();
    	k.keyPress(KeyEvent.VK_ENTER);
    	
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// search btn
    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();	// download btn
    	Thread.sleep(2000);   	    	
    }
    
    @Test(enabled = true)	// Approve/Reject Report
    public void menu5() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[4]")).click();	// go to App/Rej Report
    	Thread.sleep(6000);    	
    	driver.findElement(By.xpath("//input[@placeholder='Enter DocumentNo or CIF ']")).sendKeys("");    	    	
    	
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//span[@class=' css-1okebmr-indicatorSeparator']/following-sibling::div)[1]")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//div[text()='APPROVED']")).click(); // Rejected, Pre_Approveded Pre_Rejected
    	
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// search btn
    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();	// download btn
    	Thread.sleep(2000);
    	    	
    }    

    @Test(enabled = true)	// User Progress Report
    public void menu6() throws InterruptedException, AWTException {
    	
    	driver.getCurrentUrl();
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//a[@class='nav-link text-left'])[5]")).click();	// go to Progress Report
    	Thread.sleep(6000);    	
    	driver.findElement(By.xpath("//input[@placeholder='Enter DocumentNo or CIF ']")).sendKeys("");    	    	
    	
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//span[@class=' css-1okebmr-indicatorSeparator']/following-sibling::div)[1]")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//div[text()='MAKER']")).click(); // CHECKER
    	Thread.sleep(3000);
    	driver.findElement(By.xpath("(//span[@class=' css-1okebmr-indicatorSeparator']/following-sibling::div)[2]")).click();
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//div[text()='Aye Min Than']")).click(); // name
    	
    	Thread.sleep(2000);
    	driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();	// search btn
    	Thread.sleep(2000);
//    	driver.findElement(By.xpath("//button[@class='btn btn-danger']")).click();	// download btn
    	Thread.sleep(2000);
    	    	
    }
*/        
    
    @AfterClass
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(10000);		
		driver.quit();
		System.out.println("The driver closed the browser entirely.");
	}	
}
