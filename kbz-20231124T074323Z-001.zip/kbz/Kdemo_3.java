package kbz;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.datatransfer.StringSelection;
import java.awt.event.KeyEvent;
import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class Kdemo_3 {

    WebDriver driver;

    @BeforeClass
    public void startBrowser() {
    	WebDriverManager.chromedriver().setup();
    	
/*		Map<String, Object> prefers = new HashMap<String, Object>();
		prefers.put("profile.default_content_setting_values.notification",1);
		ChromeOptions chromeOpt = new ChromeOptions();
		chromeOpt.setExperimentalOption("prefs",prefers);      
		driver = new ChromeDriver(chromeOpt);
*/
        ChromeOptions options = new ChromeOptions();
        options.addArguments("use-fake-device-for-media-stream");
        options.addArguments("use-fake-ui-for-media-stream");
        options.addArguments("--allow-file-access-from-files", "--use-fake-ui-for-media-stream", "--allow-file-access",
                "--use-file-for-fake-audio-capture=D:", "--use-fake-device-for-media-stream");
        driver = new ChromeDriver(options);        
        
        driver.get("https://d2nz32r76q6j2r.cloudfront.net/");

        driver.manage().window().maximize();

    }

    @Test(enabled = true)
    public void SignIn() throws InterruptedException, AWTException {
    	
        Thread.sleep(3000);
        driver.findElement(By.xpath("//button[contains(text(),'Sign In')]")).click();
        Thread.sleep(4000);
        driver.getCurrentUrl();
        driver.findElement(By.xpath("//input[@id='formBasicEmail']")).sendKeys("maythandar.oo@kbzbank.com");
        driver.findElement(By.xpath("//input[@id='formBasicPassword']")).sendKeys("Bx01jcbw");
        driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click();
        Thread.sleep(4000);
    }
    
    @Test(enabled = true)
    private void createAcc() throws InterruptedException, AWTException {        

    	Thread.sleep(4000);
        JavascriptExecutor j = (JavascriptExecutor) driver;
        j.executeScript("window.scrollBy(0,document.body.scrollHeight)", "");
        WebElement ele = driver.findElement(By.xpath("(//a[@class='btn btn-more-primary'])[8]"));	//learn more btn
        j.executeScript("arguments[0].click();", ele);
        Thread.sleep(18000);

        JavascriptExecutor j1 = (JavascriptExecutor) driver;
        
		WebElement ele0 = driver.findElement(By.xpath("(//div[@class=' css-tlfecz-indicatorContainer'])[1]")); // 1st drop down
		j1.executeScript("arguments[0].click();", ele0);
		Thread.sleep(4000);
		driver.findElement(By.xpath("(//div[text()='SGD'])[1]")).click();
		Thread.sleep(4000);
                
        WebElement ele1 = driver.findElement(By.xpath("(//button[@class='btn btn-primary'])[1]"));	//create acc btn
        j1.executeScript("arguments[0].click();", ele1);
        Thread.sleep(8000);       
        
		
		  JavascriptExecutor j2 = (JavascriptExecutor) driver; WebElement ele2 =
		  driver.findElement(By.xpath("//input[@id='inline-radio-2']")); //gallery radio btn 
		  j2.executeScript("arguments[0].click();", ele2);
		  Thread.sleep(3000); 
		  j2.executeScript("arguments[0].click();", ele2);
		  Thread.sleep(6000);
		  
		  Actions action = new Actions(driver);
		  
		  WebElement ele3 =
		  driver.findElement(By.xpath("(//div[@class='col-md-1'])[1]")); //NRC front upload btn 
		  action.moveToElement(ele3).click().build().perform();
		  Thread.sleep(6000);
		  
		  Robot k = new Robot();
		  
		  String path = "D:\\Automation tasks"; 
		  StringSelection pathss = new StringSelection(path); // path select
		  Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pathss, null); // copied
		  
		  k.keyPress(KeyEvent.VK_CONTROL); k.keyPress(KeyEvent.VK_V);
		  k.keyRelease(KeyEvent.VK_V); k.keyRelease(KeyEvent.VK_CONTROL);
		  k.keyPress(KeyEvent.VK_ENTER);
		  
		  Thread.sleep(5000);
		  
		  String st = "WallpaperBG-1.jpg"; 
		  StringSelection ss = new StringSelection(st); //image file select
		  Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss, null); // copied
		  
		  k.keyPress(KeyEvent.VK_CONTROL); k.keyPress(KeyEvent.VK_V);
		  k.keyRelease(KeyEvent.VK_V); k.keyRelease(KeyEvent.VK_CONTROL);
		  k.keyPress(KeyEvent.VK_ENTER);
		  
		  Thread.sleep(7000);
		  
		  WebElement ele4 = driver.findElement(By.xpath("//div[@class='col-md-1']")); //NRC back upload btn 
		  action.moveToElement(ele4).click().build().perform();
		  Thread.sleep(6000);
		  
		  // no need to go to file path 
		  String st1 = "WallpaperBG-2.jpg";
		  StringSelection ss1 = new StringSelection(st1); //image file select
		  Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss1, null);
		  
		  // action.keyDown(Keys.CONTROL).sendKeys("V").keyUp(Keys.CONTROL).build().perform(); 
		  // action.keyDown(Keys.ENTER).keyUp(Keys.ENTER).build().perform();
		  k.keyPress(KeyEvent.VK_CONTROL); k.keyPress(KeyEvent.VK_V);
		  k.keyRelease(KeyEvent.VK_V); k.keyRelease(KeyEvent.VK_CONTROL);
		  k.keyPress(KeyEvent.VK_ENTER);
		  
		  Thread.sleep(7000);
		  
		  JavascriptExecutor j3 = (JavascriptExecutor) driver;
		  j3.executeScript("window.scrollBy(0,document.body.scrollHeight);", "");
		  Thread.sleep(4000); 
		  WebElement ele5 = driver.findElement(By.xpath("//button[@class='ca-continue-btn btn btn-primary']")); // cont'd btn
		  action.moveToElement(ele5).click().build().perform(); 
		  Thread.sleep(9000);
		 
//		https://d2nz32r76q6j2r.cloudfront.net/create-account/cash-saving/biomatric
		driver.findElement(By.xpath("//button[contains(@class,'ca-skip-btn btn')]")).click(); // skip for now 
		driver.navigate().to("https://d2nz32r76q6j2r.cloudfront.net/create-account/cash-account/personal-detail");
		Thread.sleep(6000);
		driver.switchTo().alert().accept();
		Thread.sleep(4000);
		
/*		// Check personal details
		JavascriptExecutor j4 = (JavascriptExecutor) driver;
		j4.executeScript("window.scrollBy(0,document.body.scrollHeight);", "");
		WebElement ele6 = driver.findElement(By.xpath("//button[contains(@class,'ca-continue-btn btn')]")); // cont'd btn
		j4.executeScript("arguments[0].click();", ele6);
		Thread.sleep(5000);
				
		JavascriptExecutor j5 = (JavascriptExecutor) driver;
		WebElement ele7 = driver.findElement(By.xpath("(//div[@class=' css-tlfecz-indicatorContainer'])[1]")); // 1st drop down
		j5.executeScript("arguments[0].click();", ele7);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[text()='Enterprise Employed']")).click();
		Thread.sleep(4000);
				
		WebElement ele8 = driver.findElement(By.xpath("(//div[@class=' css-tlfecz-indicatorContainer'])[2]")); // 2nd drop down
		j5.executeScript("arguments[0].click();", ele8);		
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[text()='Animator']")).click();
		Thread.sleep(4000);
		
		WebElement ele9 = driver.findElement(By.xpath("(//div[@class=' css-tlfecz-indicatorContainer'])[3]")); // 3rd drop down
		j5.executeScript("arguments[0].click();", ele9);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[text()='Business & Information']")).click();
		Thread.sleep(4000);
				
		WebElement ele10 = driver.findElement(By.xpath("//button[contains(@class,'ca-continue-btn btn')]")); // cont'd btn
		j5.executeScript("arguments[0].click();", ele10);
		Thread.sleep(5000);
	
		// upload signature photo
		driver.findElement(By.xpath("//button[@class='btn btn-kbz']")).click();	// upload sign photo
		Thread.sleep(5000);
		
		String path1 = "D:\\Mixed\\Icons"; 
		StringSelection pathss1 = new StringSelection(path1); // path select
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(pathss1, null); // copied
		
		Robot k = new Robot();		
		k.keyPress(KeyEvent.VK_CONTROL); k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V); k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(5000);
		
		String st2 = "beat.jpg"; 
		StringSelection ss2 = new StringSelection(st2); //image file select
		Toolkit.getDefaultToolkit().getSystemClipboard().setContents(ss2, null); // copied
		
		k.keyPress(KeyEvent.VK_CONTROL); k.keyPress(KeyEvent.VK_V);
		k.keyRelease(KeyEvent.VK_V); k.keyRelease(KeyEvent.VK_CONTROL);
		k.keyPress(KeyEvent.VK_ENTER);
		
		Thread.sleep(7000);
				
		j5.executeScript("window.scrollBy(0,document.Body.scrollHeight):", "");
		WebElement eleX1 = driver.findElement(By.xpath("//button[contains(@class,'ca-continue-btn btn')]"); // cont'd btn
		j5.executeScript("arguments[0].click();", eleX1);
		Thread.sleep(5000);
		
		// Introducer's info
		driver.findElement(By.xpath("//div[@for='yes']")).click(); // Yes btn
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[@for='no']")).click(); // No btn
		Thread.sleep(4000);
		
		driver.findElement(By.xpath("//button[contains(@class,'ca-continue-btn btn btn-primary')]")).click(); // cont'd btn
		Thread.sleep(5000);
*/		
		// Choose branch
		JavascriptExecutor j6 = (JavascriptExecutor) driver;
		WebElement eleX2 = driver.findElement(By.xpath("(//div[@class=' css-tlfecz-indicatorContainer'])[1]")); // state/division drop down
		j6.executeScript("arguments[0].click();", eleX2);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[text()='YANGON']")).click();
		Thread.sleep(4000);
				
		WebElement eleX3 = driver.findElement(By.xpath("(//div[@class=' css-tlfecz-indicatorContainer'])[2]")); // township drop down
		j6.executeScript("arguments[0].click();", eleX3);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[text()='BAHAN']")).click();
		Thread.sleep(4000);
				
		WebElement eleX4 = driver.findElement(By.xpath("(//div[@class=' css-tlfecz-indicatorContainer'])[3]")); // branch drop down
		j6.executeScript("arguments[0].click();", eleX4);
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[text()='INYAR ROAD']")).click();
		Thread.sleep(4000);
		
		j6.executeScript("window.scrollBy(0,document.Body.scrollHeight):", "");
		WebElement eleX5 = driver.findElement(By.xpath("//button[contains(@class,'ca-continue-btn btn btn-primary')]")); // cont'd btn
		j6.executeScript("arguments[0].click();", eleX5);
		Thread.sleep(5000);
		
		// Further services
		driver.findElement(By.xpath("//div[@for='W']")).click(); // weekly btn
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[@for='D']")).click(); // daily btn
		Thread.sleep(4000);
		driver.findElement(By.xpath("//div[@for='M']")).click(); // monthly btn
		Thread.sleep(4000);
		
		j6.executeScript("window.scrollBy(0,document.Body.scrollHeight):", "");
		WebElement eleX6 = driver.findElement(By.xpath("//button[contains(@class,'ca-continue-btn btn btn-primary')]")); // cont'd btn
		j6.executeScript("arguments[0].click();", eleX6);
		Thread.sleep(5000);
		
		// Summary review
		j6.executeScript("window.scrollBy(0,document.Body.scrollHeight):", "");		
		driver.findElement(By.xpath("//input[@id='default-checkbox']")).click(); // 
		Thread.sleep(4000);
		
		WebElement eleX7 = driver.findElement(By.xpath("//button[contains(@class,'ca-continue-btn btn btn-primary')]")); // cont'd btn
		j6.executeScript("arguments[0].click();", eleX7);
		Thread.sleep(5000);
	
		// T&C
//		WebElement elex8 = driver.findElement(By.xpath("//button[@class='ca-back-btn btn']")); // back btn		
		WebElement eleX8 = driver.findElement(By.xpath("//button[@class='ca-continue-btn btn btn-primary']")); // submit btn
		j6.executeScript("arguments[0].click();", eleX8);
		Thread.sleep(5000);
		
		//OTP verification
		driver.findElement(By.xpath("//input[@id='formBasicEmail']")).sendKeys("111111"); // otp keyin
		Thread.sleep(2000);
		driver.findElement(By.xpath("//button[@type='submit']")).click();	// verify btn
		Thread.sleep(4000);
		driver.findElement(By.xpath("//button[@class='btn btn-primary']")).click(); // Done
		Thread.sleep(6000);
		
    }
    
    @AfterClass
	public void closeBrowser() throws InterruptedException {
		Thread.sleep(10000);		
		driver.quit();
		System.out.println("The driver closed the browser entirely.");
	}
    
}